/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package murach.business;

/**
 *
 * @author varne
 */


/**
 *
 * @author kpm21
 */
public class ProductTableTester {
    
    public static void main(String[] args) {
        ProductTable table = new ProductTable();
        
        Product prod = new Product();
        prod.setCode("asdf1234");
        prod.setDescription("Hello World");
        prod.setPrice(100.50);
        
        
        
        //selectProducts
        System.out.println("Select Prodcuts Test:");
        for (Product x: table.selectProducts()) {
            System.out.println(x.getCode());
        }
        
        //insert product        
        table.insertProduct(prod);
        System.out.println("Select Products after inserting a product:");
        for (Product x: table.selectProducts()) {
            System.out.println(x.getCode());
        }
        
        //check exists
        System.out.println("Check if the new product exists");
        System.out.println("Exists: " + table.exists(prod.getCode()));
        
        //get a products
        System.out.println("Testing Select Product");
        Product fromTable = table.selectProduct(prod.getCode());
        System.out.println(fromTable.getCode());
        System.out.println(prod.getDescription());
        
        //update product
        System.out.println("Testing the update product function with a new description:");
        prod.setDescription("This is a new description");
        table.updateProduct(prod);
        
        //View to be sure
        System.out.println("Selecting the updated product:");
        fromTable = table.selectProduct(fromTable.getCode());
        System.out.println(fromTable.getCode());
        System.out.println(fromTable.getDescription());
        
        //delete product
        table.deleteProduct(prod);
               
        System.out.println("Select Products after product is deleted");
        for (Product x: table.selectProducts()) {
            System.out.println(x.getCode());
        }
        
    }
    
}

