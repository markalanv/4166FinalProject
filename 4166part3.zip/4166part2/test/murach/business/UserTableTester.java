/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package murach.business;
import java.io.IOException;
import java.util.ArrayList;
import murach.business.*;

/**
 *
 * @author varne
 */
public class UserTableTester {
     public static void main(String[] args) throws IOException {
       
        
        User user = new User();
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setEmail("johndoe@gmail.com");
        user.setUsername("jdoe");
        user.setPassword("password");
        
        //addRecord and getUser
        System.out.println("Adds a user record to the database and retrieves by email:");
          UserTable.addRecord(user);
          System.out.println(UserTable.getUser("johndoe@gmail.com").getFirstName());
        
        
        //ArrayList getUsers
         System.out.println("Prints first names from array list:");
        ArrayList<User> users = UserTable.getUsers();
        for (User u: users)
        {
            System.out.println(u.getFirstName());
        }
        
        //HashMap
         System.out.println("Prints hashmap size:");
        System.out.println(UserTable.getUsersMap().size());
        
        
        
    }
}
