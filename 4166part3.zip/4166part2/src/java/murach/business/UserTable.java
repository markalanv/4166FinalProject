package murach.business;

import java.io.*;
import java.util.*;
import java.sql.*;
import murach.business.User;

public class UserTable {
    
    static String url = "jdbc:mysql://localhost:3306/shop";
    static String username = "root";
    static String password = "College123!";
    
    static Connection connection = null;
    static PreparedStatement selectProduct = null;
    static ResultSet resultset = null;
	
	//Static initializer, it runs when the class is intialized (it is executed once)
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
    }
    
    static {
        try {
            connection = DriverManager.getConnection (url, username, password);
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
    }
    
    public static void addRecord(User user) throws IOException {
        try {
            connection = DriverManager.getConnection(url, username, password);
            String preparedSQL = "INSERT INTO shop.users (firstName,lastName,email,password,username) VALUES (?,?,?,?,?);";
          
            selectProduct = connection.prepareStatement(preparedSQL);
            selectProduct.setString(1, user.getFirstName());
            selectProduct.setString(2, user.getLastName());
            selectProduct.setString(3, user.getEmail());
            selectProduct.setString(5, user.getUsername());
            selectProduct.setString(4, user.getPassword());
            selectProduct.executeUpdate();
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
		//throw new NotImplementedException(); // remove this line and implement the logic

    }

    public static User getUser(String emailAddress) throws IOException {
        User user = new User();
        boolean sqlWork = false;
        try {
            String preparedSQL = "SELECT firstName,lastName,email,password FROM shop.users WHERE email = ?;";
            selectProduct = connection.prepareStatement(preparedSQL);
            selectProduct.setString(1, emailAddress);
            resultset = selectProduct.executeQuery();
            
            while (resultset.next()) {
                user.setFirstName(resultset.getString("firstName"));
                user.setLastName(resultset.getString("lastName"));
                user.setEmail(resultset.getString("email"));
                user.setPassword(resultset.getString("password"));
            }
            sqlWork = true;
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
        if (!sqlWork) {
            user = null;
        }
        return user;
        //throw new NotImplementedException(); // remove this line and implement the logic

    }

    public static ArrayList<User> getUsers() throws IOException {

		ArrayList<User> userList = new ArrayList();
                
             
        boolean sqlWork = false;
        try {
            String preparedSQL = "SELECT * FROM shop.users;";
            selectProduct = connection.prepareStatement(preparedSQL);
            resultset = selectProduct.executeQuery();
            
            while (resultset.next()) {
                User user = new User();
                user.setFirstName(resultset.getString("firstName"));
                user.setLastName(resultset.getString("lastName"));
                user.setEmail(resultset.getString("email"));
                user.setUsername(resultset.getString("username"));
                user.setPassword(resultset.getString("password"));
                userList.add(user);
            }
            sqlWork = true;
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
        
        return userList;
                
    }

    public static HashMap<String, User> getUsersMap() throws IOException {
       
		HashMap<String, User> usershashmap = new HashMap<>();
        for (User u : getUsers())
        {
            usershashmap.put(u.getEmail(), u);
        }
        return usershashmap;
    }
}