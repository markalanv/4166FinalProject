/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package murach.business;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author varne
 */
public class ProductManagementServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String action = request.getParameter("action");
        String url = "";
        HttpSession session = request.getSession();
        switch (action) {
            case "displayProducts":
                getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);
                break;
            case "addProduct":
                getServletContext().getRequestDispatcher("/product.jsp").forward(request, response);
                break;
            case "editProduct":
                
                     getServletContext().getRequestDispatcher("/product.jsp").forward(request, response);
                      
                break;

            case "deleteProduct":
                getServletContext().getRequestDispatcher("/confirmDelete.jsp").forward(request, response);
                break;
              
            case "actuallyDelete":
                System.out.println("Requested to delete" + request.getParameter("productCode"));
                Product p = ProductTable.selectProduct(request.getParameter("productCode"));
                ProductTable.deleteProduct(p);
                
                 getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);
                break;
            default:
                break;
        }
        
        
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
        System.out.println("product post is here");
      
        //Get action parameter
        String action = request.getParameter("action");
          System.out.println("action "+action);

        //If user is not logged in, forward to the login page
        if (action.equals("login")) {
            
            HttpSession session = request.getSession();
            User user = (User)session.getAttribute("user");
            
            if (user.getPassword()==null)
            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
            else
            {
                getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);
            }
        }

        //User is logged in, proceed to updateProduct if appropriate action parameter
        switch (action) {
            case "updateProduct":
            {       // not implemented
                    break;
                    }
            case "addProduct":
                    
                
                    //Get the the values to put into the new product
                    String code = request.getParameter("code");
                    String desc = request.getParameter("desc");
                    Double price = Double.parseDouble(request.getParameter("price"));

                    //Create new product object and put in the values
                    Product newProduct = new Product();
                    newProduct.setCode(code);
                    newProduct.setDescription(desc);
                    newProduct.setPrice(price);
                    
                    //get the product list from the session, if any 
                    HttpSession session = request.getSession();
                    
                    ArrayList<Product> products = (ArrayList<Product>) ProductTable.selectProducts();
                    
                    if(products==null)
                    {
                        products =  new ArrayList<>();
                        
                    }
                     if (session.getAttribute("edit") != null)
                    {
                        int i = (Integer) session.getAttribute("edit");
                        newProduct = products.get(i);
                        
                        ProductTable.deleteProduct(ProductTable.selectProduct(newProduct.getCode()));
                       
                       
                      
                     newProduct.setCode(code);
                    newProduct.setDescription(desc);
                    newProduct.setPrice(price);
                     ProductTable.insertProduct(newProduct);
                    
                    
                    session.setAttribute("edit", null);
                    }
                    else
                    {
                    //add product to list
                        ProductTable.insertProduct(newProduct);
                    }
                    // replacing the old list in the session by a the new list (that contains the new product we just added)
                    session.removeAttribute("products");
                    session.setAttribute("products", products);
                    
                    //Redirect back to products page
                    getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);
               
                break;
            default:
                System.err.println("He's dead, Jim!");
                break;
        }
        }

    
    }
      
      


