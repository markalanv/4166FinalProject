/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package murach.business;
import java.io.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.*;
import javax.servlet.http.*;
//import murach.data.UserIO;

/**
 *
 * @author varne
 */
public class MembershipServlet extends HttpServlet {

  
protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MembershipServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MembershipServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
         String action = request.getParameter("action");

        //Make a big decision
        switch (action) {
            case "login":
                getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
                break;
            case "signup":
                getServletContext().getRequestDispatcher("/signup.jsp").forward(request, response);
                break;
            case "logout":
                    //not implemented
                 HttpSession session = request.getSession();
                 session.invalidate();
              getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
                break;
            default:
                break;
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
         //Get the action and session
        String action = request.getParameter("action");
        HttpSession session = request.getSession();

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MembershipControllerServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Membership Servlet</h1>");
           
            //********** LOGIN **********
            //If action is login, login the user
            if ("login".equals(action)) {
                
                //Get the parameters
                String username = request.getParameter("username");
                String password = request.getParameter("password");
                
                User user =  UserTable.getUser(username);
                
                
                
                if (user != null)
                {
                    
                    if(!username.equals(user.getEmail()) || !password.equals(user.getPassword()))
                    {
                        //username or password is incorrect
                        out.println("<p> Invalid username or password </p>");
                    }
                    else
                    {
                        //user is verified
                        session = request.getSession();
                        session.setAttribute("user", user);
                         
                        getServletContext().getRequestDispatcher("/products.jsp").forward(request, response);
                    }
                    
                }
                
                else
                {
                    //username or password is incorrect
                        out.println("<p> Invalid username or password </p>"); 
                }
                
            } 
            else if ("signup".equals(action)) 
            {

                //Validate Method will print out error if any of the input from parameters is invalid
 
                
                //Get the parameters
                String firstName = request.getParameter("firstName");
                String lastName = request.getParameter("lastName");
                String email = request.getParameter("e-mail");
                String password = request.getParameter("password");
                String username = request.getParameter("username");
                //Create new user object and put the information in it
                User user = new User();
                user.setEmail(email);
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setPassword(password);
                user.setUsername(username);

                
                UserTable.addRecord(user);
                //Put user object into session attribute
                session.setAttribute("user", user);
               
                 
                  
                out.println("<p>Successfully created new user " + user.getFirstName() + "</p>");
                out.println("<p><a href=\"index.jsp\">Return to Index</a></p>");
                
                
            }
            out.println("</body>");
            out.println("</html>");
        }
    
    }  
}
      
   
    


