package murach.business;


import java.sql.*;
import java.util.*;
//import murach.business.Product;


//
public class ProductTable {

    static String url = "jdbc:mysql://localhost:3306/shop";
    static String username = "root";
    static String password = "College123!";
    
    static Connection connection = null;
    static PreparedStatement selectProduct = null;
    static ResultSet resultset = null;
    private static Statement stmt = null;

	
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
    }
    
    static {
        try {
            connection = DriverManager.getConnection (url, username, password);
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
    }
    
    public static List<Product> products = null;
    //stores all products in a List
    public static List<Product> selectProducts() {
        try {
            String preparedSQL = "SELECT * FROM products;";
            selectProduct = connection.prepareStatement(preparedSQL);
            resultset = selectProduct.executeQuery();
            products = new ArrayList<>();
        
            while (resultset.next()) {
                Product p = new Product();
                p.setCode(resultset.getString(2));
                p.setDescription(resultset.getString(3));
                p.setPrice(resultset.getDouble(4));
       
                products.add(p);
            }
            
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
           
        }
        return products;
		
    }
    //find product in table
    public static Product selectProduct(String productCode) {
        Product product = new Product();
        boolean sqlWork = false;
        try {
            String preparedSQL = "SELECT code,description,price FROM shop.products WHERE code = ?;";
            selectProduct = connection.prepareStatement(preparedSQL);
            selectProduct.setString(1, productCode);
            resultset = selectProduct.executeQuery();
            
            while (resultset.next()) {
                product.setCode(resultset.getString("code"));
                product.setDescription(resultset.getString("description"));
                product.setPrice(resultset.getDouble("price"));
                
            }
            sqlWork = true;
        }
        catch (SQLException e) {
            for (Throwable t : e)
            { t.printStackTrace();
            }
        }
        if (!sqlWork) {
            product = null;
        }
        return product;
		
    }
    
    //checks if product exists in table
    
public boolean exists(String productCode) {
        boolean sqlWork = false;
        try {
            String preparedSQL = "SELECT code,description,price FROM shop.products WHERE code = ?;";
            selectProduct = connection.prepareStatement(preparedSQL);
            selectProduct.setString(1, productCode);
            resultset = selectProduct.executeQuery();
            
            sqlWork = true;
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
        if (!sqlWork) {
            return false;
        }
        return true;
		
    }
    
    //adds list of products to table
    private static void saveProducts(List<Product> products) {
        try {
            for(int i =0; i < products.size(); i++)
            {
            String preparedSQL = "INSERT INTO shop.products (code, description, price) VALUES (?,?,?);";
            selectProduct = connection.prepareStatement(preparedSQL);
            selectProduct.setString(1, products.get(i).getCode());
            selectProduct.setString(2, products.get(i).getDescription());
            selectProduct.setString(3, products.get(i).getPriceCurrencyFormat());
           
            selectProduct.executeUpdate();
            }
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
		
        
    }
    
    //insert single product into table
    public static void insertProduct(Product product) {
         try {
            String preparedSQL = "INSERT INTO shop.products (code, description, price) VALUES (?,?,?);";
            selectProduct = connection.prepareStatement(preparedSQL);
            selectProduct.setString(1, product.getCode());
            selectProduct.setString(2, product.getDescription());
            selectProduct.setDouble(3, product.getPrice());
           
            selectProduct.executeUpdate();
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
		//throw new NotImplementedException(); // remove this line and implement the logic
    }

    //update product in table
    public static void updateProduct(Product product) {
        try {
            String preparedSQL = "UPDATE shop.products \n" +
              "SET code = '" + product.getCode() + "' , description = '" + product.getDescription() + "' , price = '"+ product.getPrice() + "' \n" +
              "WHERE code = '" + product.getCode()+ "';";
           
            selectProduct = connection.prepareStatement(preparedSQL);
         
            selectProduct.executeUpdate();
        }
        catch (SQLException e) {
            for (Throwable t : e)
                t.printStackTrace();
        }
		
    }    
    
    //delete product from table
    public static void deleteProduct (Product product) {
        
       try {
            String preparedSQL = "DELETE FROM shop.products WHERE code = '" + product.getCode()+ "';";
           
            selectProduct = connection.prepareStatement(preparedSQL);
         
            selectProduct.executeUpdate();
        }
        catch (SQLException e) {
            for (Throwable t : e) {
             }
        }
		
    }
    
    
    
    
}